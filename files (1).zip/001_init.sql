-- Sri Geetha Fashions Hub: permanent database, security rules and photo storage.
-- Paste ALL of this into Supabase > SQL Editor > New query > Run. Safe to run once.

-- ---------- owners ----------
create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.admins enable row level security;   -- no policies: not readable from the browser

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;

-- ---------- products (same fields your website already uses) ----------
create table if not exists public.products (
  id text primary key check (id ~ '^[A-Za-z0-9_-]{1,40}$'),
  name text not null check (char_length(name) between 2 and 160),
  description text not null default '',
  cat text not null default 'Sarees' check (cat in ('Sarees','Women','Men','Kids','Jewellery','Gifts')),
  type text,
  price numeric(10,2) not null check (price > 0),          -- selling price
  mrp numeric(10,2) not null check (mrp > 0),              -- cost price / MRP
  sku text unique,
  sizes text[] not null default '{}',
  colours text[] not null default '{}',
  image_urls text[] not null default '{}',                 -- permanent Supabase Storage links
  c1 text not null default '#8E1B4F',
  c2 text not null default '#D9A441',
  badge text not null default '',
  featured boolean not null default false,
  active boolean not null default true,
  stock_quantity integer check (stock_quantity is null or stock_quantity >= 0),   -- empty = not tracked
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (price <= mrp)
);
create index if not exists products_active_idx on public.products(active, featured, created_at desc);

create or replace function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;
drop trigger if exists products_touch on public.products;
create trigger products_touch before update on public.products for each row execute function public.touch_updated_at();

-- ---------- orders, bookings, messages, settings ----------
create table if not exists public.orders (id text primary key, data jsonb not null, created_at timestamptz not null default now());
create table if not exists public.bookings (id text primary key, data jsonb not null, created_at timestamptz not null default now());
create table if not exists public.inquiries (id text primary key, data jsonb not null, created_at timestamptz not null default now());
create index if not exists orders_created_idx on public.orders(created_at desc);
create table if not exists public.store_settings (id integer primary key default 1 check (id = 1), data jsonb not null default '{}'::jsonb);
insert into public.store_settings (id, data) values (1, '{}') on conflict (id) do nothing;

-- ---------- row level security ----------
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.bookings enable row level security;
alter table public.inquiries enable row level security;
alter table public.store_settings enable row level security;

create policy "public reads active products" on public.products for select to anon, authenticated using (active or public.is_admin());
create policy "admin writes products" on public.products for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "public reads store settings" on public.store_settings for select to anon, authenticated using (true);
create policy "admin writes store settings" on public.store_settings for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Orders, bookings and messages: customers have NO direct access. They can only submit through the functions below.
create policy "admin manages orders" on public.orders for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "admin manages bookings" on public.bookings for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "admin manages inquiries" on public.inquiries for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- ---------- secure order creation: item prices and the subtotal come from the database, never from the browser ----------
create or replace function public.submit_order(doc jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  it jsonb; p public.products; q integer; sub numeric := 0; items jsonb := '[]'::jsonb;
  ship numeric; gift numeric; oid text; ph text; result jsonb;
begin
  oid := doc->>'id'; ph := coalesce(doc->>'phone', '');
  if oid is null or oid !~ '^[A-Za-z0-9-]{6,40}$' then raise exception 'Invalid order code'; end if;
  if char_length(trim(coalesce(doc->>'name',''))) not between 2 and 100 then raise exception 'Please enter your name'; end if;
  if ph !~ '^[0-9+() -]{7,15}$' then raise exception 'Please enter a valid phone number'; end if;
  if char_length(trim(coalesce(doc->>'addr',''))) not between 5 and 500 then raise exception 'Please enter your delivery address'; end if;
  if char_length(coalesce(doc->>'pin','')) > 10 or char_length(coalesce(doc->>'note','')) > 500 or char_length(coalesce(doc->>'pay','')) > 20 then raise exception 'Some details are too long'; end if;
  if jsonb_typeof(doc->'items') <> 'array' or jsonb_array_length(doc->'items') not between 1 and 30 then raise exception 'Your cart is empty'; end if;
  if char_length(doc::text) > 20000 then raise exception 'Order is too large'; end if;
  if (select count(*) from public.orders where data->>'phone' = ph and created_at > now() - interval '1 hour') >= 5 then
    raise exception 'Too many orders from this number. Please try again later';
  end if;

  for it in select * from jsonb_array_elements(doc->'items') loop
    q := (it->>'qty')::integer;
    if q is null or q < 1 or q > 20 then raise exception 'Invalid quantity'; end if;
    select * into p from public.products where id = it->>'id' and active for update;
    if not found then raise exception 'A product in your cart is no longer available. Please refresh the page'; end if;
    if p.stock_quantity is not null then
      if p.stock_quantity < q then raise exception '% has only % left in stock', p.name, p.stock_quantity; end if;
      update public.products set stock_quantity = stock_quantity - q where id = p.id;
    end if;
    sub := sub + p.price * q;
    items := items || jsonb_build_object('id', p.id, 'name', p.name, 'size', nullif(it->>'size',''), 'qty', q, 'price', p.price);
  end loop;

  ship := least(greatest(coalesce((doc->>'ship')::numeric, 0), 0), 1000);
  gift := least(greatest(coalesce((doc->>'giftFee')::numeric, 0), 0), 1000);
  result := doc || jsonb_build_object('items', items, 'sub', sub, 'ship', ship, 'giftFee', gift,
    'total', sub + ship + gift, 'status', 'New', 'payStatus', 'Pending', 'createdAt', now());
  insert into public.orders (id, data) values (oid, result);
  return result;
end $$;

-- bookings and messages: validated, size-limited and rate-limited
create or replace function public.submit_form(kind text, doc jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare fid text := doc->>'id'; ph text := coalesce(doc->>'phone', '');
begin
  if kind not in ('booking', 'inquiry') then raise exception 'Unknown form'; end if;
  if fid is null or fid !~ '^[A-Za-z0-9-]{4,40}$' then raise exception 'Invalid reference'; end if;
  if char_length(doc::text) > 8000 then raise exception 'Message is too long'; end if;
  if ph <> '' and ph !~ '^[0-9+() -]{7,15}$' then raise exception 'Please enter a valid phone number'; end if;
  if kind = 'booking' then
    if (select count(*) from public.bookings where created_at > now() - interval '1 hour') >= 40 then raise exception 'Please try again later'; end if;
    insert into public.bookings (id, data) values (fid, doc || jsonb_build_object('createdAt', now()));
  else
    if (select count(*) from public.inquiries where created_at > now() - interval '1 hour') >= 40 then raise exception 'Please try again later'; end if;
    insert into public.inquiries (id, data) values (fid, doc || jsonb_build_object('createdAt', now()));
  end if;
  return jsonb_build_object('ok', true);
end $$;

-- a customer can cancel their own NEW order if they know its code
create or replace function public.cancel_order(order_id text) returns boolean
language plpgsql security definer set search_path = public as $$
begin
  update public.orders set data = data || '{"status":"Cancelled"}'::jsonb where id = order_id and data->>'status' = 'New';
  return found;
end $$;

-- owner-only: change fields inside an order, booking or message
create or replace function public.merge_doc(kind text, doc_id text, patch jsonb) returns boolean
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Owner login required'; end if;
  if kind = 'orders' then update public.orders set data = data || patch where id = doc_id;
  elsif kind = 'bookings' then update public.bookings set data = data || patch where id = doc_id;
  elsif kind = 'inquiries' then update public.inquiries set data = data || patch where id = doc_id;
  else raise exception 'Unknown kind'; end if;
  return found;
end $$;

revoke all on function public.submit_order(jsonb), public.submit_form(text, jsonb), public.cancel_order(text), public.merge_doc(text, text, jsonb) from public;
grant execute on function public.submit_order(jsonb), public.submit_form(text, jsonb), public.cancel_order(text), public.is_admin() to anon, authenticated;
grant execute on function public.merge_doc(text, text, jsonb) to authenticated;

-- ---------- permanent product photo storage ----------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('product-images', 'product-images', true, 5242880, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update set public = true, file_size_limit = 5242880, allowed_mime_types = array['image/jpeg', 'image/png', 'image/webp'];
create policy "anyone can view product images" on storage.objects for select using (bucket_id = 'product-images');
create policy "admins upload product images" on storage.objects for insert to authenticated with check (bucket_id = 'product-images' and public.is_admin());
create policy "admins replace product images" on storage.objects for update to authenticated using (bucket_id = 'product-images' and public.is_admin());
create policy "admins delete product images" on storage.objects for delete to authenticated using (bucket_id = 'product-images' and public.is_admin());

-- ---------- your existing sample products: added as HIDDEN (you had hidden them). Use Show in the owner panel to display any. ----------
insert into public.products (id, name, description, cat, type, price, mrp, sizes, badge, featured, c1, c2, active) values
  ('s1','Kanchipuram-style Silk Saree','Rich silk with a woven temple border and zari pallu. Blouse piece included.','Sarees','saree',8999,12999,'{"Free size"}','Bestseller',true,'#8E1B4F','#D9A441', false),
  ('s2','Ikat Cotton Saree','Soft handloom cotton with ikat weave. Light for all-day wear.','Sarees','saree',2299,3499,'{"Free size"}','New',true,'#1E4D7A','#E8A23A', false),
  ('s3','Pattu Wedding Saree','Heavy pattu in peacock green with a wide gold border.','Sarees','saree',7499,9999,'{"Free size"}','',false,'#0F6B5F','#D9A441', false),
  ('s4','Everyday Cotton Saree','Breathable cotton in rani pink for daily and office wear.','Sarees','saree',1299,1899,'{"Free size"}','',false,'#B3125A','#F0C25E', false),
  ('w1','Anarkali Kurta Set','Flowing Anarkali kurta with embroidered yoke and matching bottom.','Women','kurta',1899,2999,'{"S","M","L","XL"}','Festive',true,'#5B2A86','#E9B949', false),
  ('w2','Bridal Lehenga','Full-flare lehenga with zari border, blouse and dupatta. Fitting available in store.','Women','lehenga',17999,24999,'{"S","M","L","XL"}','Bridal',true,'#A3123F','#F0C25E', false),
  ('w3','Festive Half-saree Set','Langa, blouse and dupatta set for festivals and functions.','Women','lehenga',3999,5999,'{"S","M","L","XL"}','',false,'#1E4D7A','#F0C25E', false),
  ('m1','Silk Kurta with Dhoti','Festive silk kurta paired with a gold-border dhoti.','Men','kurta',2499,3499,'{"M","L","XL","XXL"}','',false,'#C9922B','#7A1D3A', false),
  ('m2','Linen Kurta','Cool linen kurta for summer functions and casual wear.','Men','kurta',1199,1799,'{"M","L","XL","XXL"}','New',false,'#2E5E5A','#D9A441', false),
  ('k1','Pattu Pavadai for Girls','Traditional silk langa and blouse in bright festive colours.','Kids','kids',1599,2499,'{"2-3 yrs","4-5 yrs","6-7 yrs"}','',false,'#C2185B','#F0C25E', false),
  ('j1','Temple Necklace, Gold-plated','Gold-plated temple necklace with a pendant. Pairs with silk sarees.','Jewellery','necklace',2799,3999,'{}','Bestseller',true,'#4A1260','#C2185B', false),
  ('j2','Jhumka Earrings','Classic jhumkas with pearl drops. Light and easy to wear.','Jewellery','jhumka',599,899,'{}','',false,'#0F4C5C','#C2185B', false),
  ('j3','Kundan Bangle Set','Set of stone-studded bangles in gold finish.','Jewellery','bangles',999,1499,'{}','',false,'#5B2A86','#E63B7A', false),
  ('g1','Festive Gift Hamper','A ready-to-give hamper in a ribboned box. Add gift wrap and a message card at checkout.','Gifts','gift',2999,3999,'{}','Gift',true,'#B3346A','#E8C27A', false),
  ('g2','Jewellery Gift Box','Earrings and bangles presented in a gift box.','Gifts','gift',1099,1499,'{}','Gift',false,'#5B2A86','#E8C27A', false),
  ('g3','Silk Saree Gift Set','A silk saree with blouse piece, packed in a gift box.','Gifts','gift',4499,5999,'{}','Gift',true,'#0F6B5F','#E8C27A', false),
  ('g4','Kids Festive Gift Set','A festive outfit for girls, boxed and ready to gift.','Gifts','gift',1499,1999,'{}','Gift',false,'#C2185B','#E8C27A', false)
on conflict (id) do nothing;
