// Enter the two values from Supabase > Project Settings > API (README step 4).
// The anon (public) key is meant to be public: the database security rules protect your data.
// NEVER paste the service_role / secret key here.
window.SGFH_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT-ID.supabase.co",
  SUPABASE_ANON_KEY: "YOUR-PUBLIC-ANON-KEY"
};
